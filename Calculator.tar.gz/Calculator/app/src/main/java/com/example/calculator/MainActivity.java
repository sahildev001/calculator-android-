package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText editTextNumber1,editTextNumber2;
    TextView tvAns;
    Button btnAdd,btnMul,btnSub,btnDiv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextNumber1 = findViewById(R.id.editTextNumber1);
        editTextNumber2 = findViewById(R.id.editTextNumber2);
        tvAns = findViewById(R.id.Ans);
        btnAdd =findViewById(R.id.btnAdd);
        btnMul = findViewById(R.id.btnMul);
        btnSub =findViewById(R.id.btnSub);
        btnDiv = findViewById(R.id.btnDiv);


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int firstValue ,secondValue, ans;

                firstValue =Integer.parseInt(editTextNumber1.getText().toString());
                secondValue =Integer.parseInt(editTextNumber2.getText().toString());
                ans=firstValue + secondValue;
                tvAns.setText("Ans = "+ans);
            }
        });

        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int firstValue ,secondValue, ans;

                firstValue =Integer.parseInt(editTextNumber1.getText().toString());
                secondValue =Integer.parseInt(editTextNumber2.getText().toString());
                ans=firstValue - secondValue;
                tvAns.setText("Ans = "+ans);
            }
        });

        btnMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int firstValue ,secondValue, ans;

                firstValue =Integer.parseInt(editTextNumber1.getText().toString());
                secondValue =Integer.parseInt(editTextNumber2.getText().toString());
                ans=firstValue * secondValue;
                tvAns.setText("Ans = "+ans);
            }
        });

        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int firstValue ,secondValue, ans;

                firstValue =Integer.parseInt(editTextNumber1.getText().toString());
                secondValue =Integer.parseInt(editTextNumber2.getText().toString());
                ans=firstValue / secondValue;
                tvAns.setText("Ans = "+ans);
            }
        });
    }
}